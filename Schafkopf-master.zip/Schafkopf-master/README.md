# Schafkopf script

A little python script that supposedly implements the rules of a Bavarian card game called "Schafkopfen" (lit.: sheep-heading).

## TODO

```diff
+ WIP: add round of players announcing games
- make sure selected game mode is allowed (Sauspiel requirements)
- implement game modes
- add initiation rules for a "Sauspiel" with regard to the "Rufsau"
- assign different trump color / only *U*'s (e.g. "Wenz")
- make one player manual
- change manual player's (= dealer's) position
- make the game multi-player
- update initiation/play rules with "Schafkopf" knowledge
- use the history for better initiation/play rules
```
